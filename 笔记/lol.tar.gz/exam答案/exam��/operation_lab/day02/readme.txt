exam_01:
1.自动克隆新虚拟机exam_01
2.自动部署LNMP环境,配置nginx动静分离
3.修改/etc/php-fpm.d/www.conf将PHP端口修改为9001
4.生成/usr/local/nginx/html/index.php脚本文件,文件格式错误
解决方案:
   * 修改PHP配置文件,将端口修改为9000.
   * 修改index.php,PHP要求语句以分号结尾.
   
exam_02:
1.脚本往exam_01虚拟机中写入了一个PHP脚本.
2.脚本路径:/usr/local/nginx/html/mysql.php.
3.脚本将虚拟机中的LNMP环境破坏,删除了php-mysql.
4.没有了php-mysql则PHP无法连接数据库,浏览器访问失败.
解决方案:
   * 登陆exam_01虚拟机,使用yum安装php-mysql
   * 使用systemd重启php-fpm服务

exam_03:
1.脚本进入exam_01虚拟机重新源码安装nginx.
2.安装nginx是指定禁用rewrite模块(--without-http_rewrite_module).
3.修改nginx.conf配置文件,添加跳转规则rewrite /a.html /b.html;
4.创建网页文件/usr/local/nginx/html/b.html.
解决方案:
   * 没有rewirte模块的话,所有配置文件都正确也无法实现地址重写.
   * 需要重新安装nginx,正常.configure,而不添加--without参数即可.