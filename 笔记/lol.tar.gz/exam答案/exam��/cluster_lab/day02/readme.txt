Exam_01:
   1.脚本创建了一个keepalived高可用web集群环境,具体配置如下:
       web1_IP:201.1.1.100,web2_IP:201.1.1.200.
       web1和web2都安装部署了keepalived,VIP为201.1.1.18.
   2.keepalived配置文件中的virtual_ipaddress { 201.1.1.18配置错误.
   3.keepalived配置文件中的interface eth0配置错误.
   4.keepalived配置文件的主从优先级一样(不是致命错误,但是推荐修改).
解决方案:
   * 修改keepalived.conf文件
   * interface eth0修改为interface eth2
   * virtual_ipaddress { 201.1.1.18修改为
   *  virtual_ipaddress { 
   *    201.1.1.18
   * 注意IP是需要独占一行.
